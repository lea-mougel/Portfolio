#include "enseignant.h"

enseignant::enseignant()
{

}

void enseignant::afficher()
{
    string texte="";
    if(this->getSexe()=='F'){
        texte+="L'étudiante s'appelle "+this->nom;
    }
    else{
        if(this->getSexe()=='M'){
            texte+="L'étudiant s'appelle "+this->nom;
        }
        else{
            texte+="L'étudiant.e s'appelle "+this->nom;
        }
    }
    if(this->numcarte!=""){
        texte+=" (carte = "+this->numcarte+")";
    }
    cout<<texte<<endl;


}
