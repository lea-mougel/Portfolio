#ifndef ETUDIANT_H
#define ETUDIANT_H

#include "/home/leam/Bureau/SLAM/A2/LYCEEC++/LYCEE/personne.h"
#include<iostream>
#include <string>
using namespace std;

class etudiant : public personne
{
    private:
        string numcarte;
    public:
        etudiant(string nom, string num);
        etudiant(string nom,string num, char sexe);
        virtual void afficher();
};

#endif // ETUDIANT_H
