#include <iostream>
#include "/home/leam/Bureau/SLAM/A2/LYCEEC++/LYCEE/personne.h"
#include "etudiant.h"
#include<vector>
using namespace std;

int main()
{
    etudiant jean("Jean","001",'M');
    jean.afficher();
    personne jack("Jack",'M');
    jack.afficher();
    personne * calypso= new personne("Calypso",'F');
    calypso->afficher();
    etudiant estelle("Estelle","002",'F');
    estelle.afficher();
    cout<<endl<<endl;
    /*héritage, vector, polymorphisme*/
    vector<personne *> Vector_pers (5);
    Vector_pers[0]=calypso;
    Vector_pers[1]=&estelle;
    Vector_pers[2]=&jack;
    Vector_pers[3]=&jean;
    for(auto e : Vector_pers)
    {
       e->afficher();
    }
}
