#ifndef ENSEIGNANT_H
#define ENSEIGNANT_H

#include "/home/leam/Bureau/SLAM/A2/LYCEEC++/LYCEE/personne.h"
#include<iostream>
#include <string>
using namespace std;

class enseignant : public personne
{
private:
    string matiere;
    float salaire;
public:
    enseignant();
    virtual void afficher();
};

#endif // ENSEIGNANT_H

