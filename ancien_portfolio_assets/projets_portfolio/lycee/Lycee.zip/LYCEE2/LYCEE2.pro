TEMPLATE = app
CONFIG += console c++11
CONFIG -= app_bundle
CONFIG -= qt

SOURCES += \
        ../LYCEE/personne.cpp \
        enseignant.cpp \
        etudiant.cpp \
        main.cpp

HEADERS += \
    ../LYCEE/personne.h \
    enseignant.h \
    etudiant.h
