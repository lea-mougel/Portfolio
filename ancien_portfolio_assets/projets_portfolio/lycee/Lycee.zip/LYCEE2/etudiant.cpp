#include "etudiant.h"

etudiant::etudiant(string nom, string num)
         : personne(nom),numcarte(num)
{
    cout << " constructeur de l'étudiant.e : « "<< nom << " " <<num<<endl;
}

etudiant::etudiant(string nom, string num,char sexe)
         : personne(nom),numcarte(num)
{
    this->setSexe(sexe);
}
void etudiant::afficher()
{
    string texte="";
    if(this->getSexe()=='F'){
        texte+="L'étudiante s'appelle "+this->nom;
    }
    else{
        if(this->getSexe()=='M'){
            texte+="L'étudiant s'appelle "+this->nom;
        }
        else{
            texte+="L'étudiant.e s'appelle "+this->nom;
        }
    }
    if(this->numcarte!=""){
        texte+=" (carte = "+this->numcarte+")";
    }
    cout<<texte<<endl;


}


