#ifndef PERSONNE_H
#define PERSONNE_H

#include<iostream>
#include <string>
using namespace std;

class personne
{
protected:
    string nom;
    void setSexe(char sexe);
    char getSexe();
private:
    char sexe;
public:
    personne();
    personne(string nom); //constructeur
    personne(string nom, char sexe);
    void setNom(string nom);
    string getNom();
    virtual void afficher();
};

#endif // PERSONNE_H
