#include "personne.h"

personne::personne()
{
}
personne::personne(string nom)
{
    this->nom=nom;
}
personne::personne(string nom,char sexe)
{
    this->nom=nom;
    if(sexe=='M' or sexe=='F'){
        this->sexe=sexe;
    }
}
void personne::setNom(string nom)
{
    this->nom=nom;
}
string personne::getNom()
{
    return(this->nom);
}
 void personne::afficher()
{
    cout<<"La personne s'appelle "<<this->nom;
    if(this->sexe=='F'){
        cout<<", cette personne est une femme";
    }
    else{
        if(this->sexe=='M'){
            cout<<", cette personne est un homme";
        }
    }
    cout<<endl;
}
void personne::setSexe(char sexe){
    if(sexe=='M' or sexe=='F'){
        this->sexe=sexe;
    }
}
char personne::getSexe(){
    return this->sexe;
}
