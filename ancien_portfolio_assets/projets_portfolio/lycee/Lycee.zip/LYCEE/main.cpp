#include <iostream>
#include"personne.h"
using namespace std;


static int n;

void afficherPersonne(personne *tabD)
{
    int i;
    for(i=0;i<n;i++)
    {
        cout<<tabD[i].getNom()<<endl;
    }
}

bool controlPersonne(personne *tabD,string nom)
{
    int i;
    bool trouve=false;
    bool premierVide=false;
    int emplacement;
    bool erreur=false;
    for(i=0;i<n and trouve==false;i++)
    {
        if(tabD[i].getNom()==nom)
        {
            trouve=true;
            cout<<"Erreur : Ce nom fait déjà partie du tableau"<<endl;
            erreur=true;
        }
        else{
            if(tabD[i].getNom()=="" and premierVide==false)
            {
                premierVide=true;
                emplacement=i;
            }
        }
    }
    if(trouve==false){
        personne pers(nom);
        auto *tab=&tabD[emplacement];
        *tab=pers;
    }
    return erreur;
}

void saisiePersonne(personne * tabD)
{
    int nbsaisi=2;//2 car 2 personnes déjà entrée dans le main
    cout<<"Contenu du tableau actuel"<<endl;
    afficherPersonne(tabD);
    string nom;
    while(nom!="FIN" and nbsaisi<n)
    {
        cout<<"Nombre de nom à entrer restant :"<<n-nbsaisi<<endl;
        cout<<"Entrez un nom ou FIN pour terminer la saisie"<<endl;
        cin>>nom;
        if(nom!="FIN"){
            bool erreur=controlPersonne(tabD,nom);
            if(erreur==false)
            {
                nbsaisi++;
            }
        }
    }
}

int main()
{
    personne pers1;
    pers1.setNom("Léa");
    personne pers2("NomVoisin");
    /* tableau statique */
    /*
    personne tabS[2]={pers1,pers2};
    int i;
    for(i=0;i<2;i++)
    {
        tabS[i].afficher();
    }*/

    cout<<"Taille du tableau dynamique"<<endl;
    cin>>n;
    while(n<=2)
    {
        cout<<"La taille du tableau doit être un entier supérieure à 2"<<endl;
        cout<<"Taille du tableau dynamique :"<<endl;
        cin>>n;
    }
    personne *tabD;
    tabD= new personne[n];
    tabD[0]=pers1;
    tabD[1]=pers2;
    saisiePersonne(tabD);
    cout<<endl<<"Contenu du tableau"<<endl;
    afficherPersonne(tabD);
}

