<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<title><?php echo $entreprise->getNom()?></title>
	<link rel="stylesheet" href="template/style1.css" >
	<?php
		$num_facture=$_GET['id'];
		$date_f=$_GET['date_'];
		$client=getClient($num_facture);
		$tab_lignes=getLigneFacture($num_facture);
		
		$total_ht=0;
	?>
</head>
<body>
	<header>
		<div class='entreprise'>
			<h2><?php echo $entreprise->getNom();?></h2>
			<p><?php echo $entreprise->getAdresse();?></p>
			<p><?php echo $entreprise->getCode_postal()." ".$entreprise->getVille();?></p>
			<p><?php echo $entreprise->getTel();?></p>
		</div>
		<div id='client'>
			<h2>Client <?php echo $client->getNumC(); ?></h2>
			<p><?php echo $client->getNomC();?></p>
			<p><?php echo $client->getAdresseC(); ?> </p>
			<p><?php echo $client->getCode_postalC()." ".$client->getVilleC();?></p>
			<p><?php echo $client->getTelC();?></p>
		</div>
	</header>
	
	<h3 class="titrepage">Facture numéro <?php echo $num_facture;?></h3>
	<h3 class="titrepage">en date du <?php echo $client->getDate_facture()?></h3>
	<table>
		<tr>
			<th>Référence</th>		
			<th>Désignation</th>		
			<th>Type</th>		
			<th>Quantité</th>		
			<th>Prix HT</th>		
			<th>Montant HT</th>		
		</tr>
		<?php
			foreach($tab_lignes as $ligne){
				$total_ht=$total_ht+$ligne->getTotal_ligne_ht();
		?>
			<tr>
				<td><?php echo $ligne->getReference(); ?></td>
				<td><?php echo $ligne->getDesignation(); ?></td>
				<td><?php echo $ligne->getType(); ?></td>
				<td><?php echo $ligne->getQuantite() ?></td>
				<td><?php echo $ligne->getTarif_facture() ?></td>
				<td><?php echo $ligne->getTotal_ligne_ht() ?></td>
			</tr>
		<?php			
			}
			$tva=$total_ht*0.2;
		?>
		<tr>
			<td colspan="6">   -------   </td>			
		</tr>
		<tr>
			<td colspan="5"> Total HT </td>		
			<td><?php echo $total_ht;?></td>		
		</tr>
		<tr>
			<td colspan="5"> TVA (20%) </td>		
			<td><?php echo $tva;?></td>		
		</tr>
		<tr>
			<td colspan="5"> Total HT </td>		
			<td><?php echo $total_ht+$tva;?></td>		
		</tr>
	</table>
	
	
</body>
</html>

