<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<title><?php echo $entreprise->getNom()?></title>
	<link rel="stylesheet" href="template/style1.css" >

</head>
<body>
	<header>
		<div class="entreprise">
			<h2><?php echo $entreprise->getNom()?></h2>
			<p><?php echo $entreprise->getAdresse().", ".$entreprise->getCode_postal()." ".$entreprise->getVille()?></p>
			<p><?php echo $entreprise->getTel()?></p>
		</div>
	</header>
	
	<h3 class="titrepage">Liste des factures</h3>
	<table>
		<tr>
			<th>N° facture</th>		
			<th>Date</th>		
			<th>Nom du client</th>		
		</tr>
		<?php
			foreach($entreprise->getListe_factures() as $facture){
		?>
			<tr>
				<td><?php echo $facture->getNumero() ?></td>
				<td><?php echo $facture->getDate() ?></td>
				<td><?php echo ($facture->getClient_f())->getNomC(); ?></td>
				<td><a href="description.php?id=<?=urlencode($facture->getNumero())?>" >Détail</a></td>
			</tr>
		<?php			
			}
		?>
	</table>
</body>
</html>

