<?php

      require("src/Entreprisemodel.php");
     $entreprise=getEntreprise();
		
		require("template/page1.php");
		//require("template/page2.php");
		
?>