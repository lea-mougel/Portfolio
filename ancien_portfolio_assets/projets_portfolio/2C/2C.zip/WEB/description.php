<?php

require("src/Entreprisemodel.php");
$entreprise=getEntreprise();

require("template/page2.php");


?>