<?php


require_once("myparam.inc.php");
require_once("classes/FactureClass.php");
require_once("Clientmodel.php");
require_once("LigneFacturemodel.php");

function getFactures(){
    // Connexion à la base de données
    try
    {
        $bdd = new PDO('pgsql:host='.HOST.';dbname=cartouche', USER, PASS);
    }
    catch(Exception $e){
          die( 'Erreur : '.$e->getMessage()   );
    }

    // On récupère les factures
    $requete = "SELECT id_facture,to_char(date_facture,'DD/MM/YYYY') as \"date_f\" FROM liste_facture";
    $req = $bdd->query($requete);
    
    if(!$req){
        $mesErreurs = $bdd->errorInfo();
        die("lecture impossible");
    }
   
    // initialisation des instances

   while ($donnees = $req->fetch())
   {
     $facture = new Facture($donnees['id_facture'],$donnees['date_f']);
     $facture->setClient_f(getClient($donnees['id_facture']));
     $facture->setListe_ligneFacture(getLigneFacture($donnees['id_facture']));
     $tabFactures[] = $facture;
   }
   $req->closeCursor();
     
	return $tabFactures;
  
    
}