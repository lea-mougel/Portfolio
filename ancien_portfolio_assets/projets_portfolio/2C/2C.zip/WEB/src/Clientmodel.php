<?php

require_once("myparam.inc.php");
require_once("classes/ClientClass.php");

function getClient($num_facture){

    // Connexion à la base de données
    try
    {
        $bdd = new PDO('pgsql:host='.HOST.';dbname=cartouche', USER, PASS);
    }
    catch(Exception $e){
          die( 'Erreur : '.$e->getMessage()   );
    }

    // On récupère les factures
    $requete = "SELECT id_client,nom,adresse,cp,ville,tel,to_char(date_facture,'DD/MM/YYYY') as \"date_facture\" FROM detail_client where id_facture=".$num_facture.";";
    $req = $bdd->query($requete);
    
    if(!$req){
        $mesErreurs = $bdd->errorInfo();
        die("lecture impossible");
    }
   
    // initialisation des instances

   while ($donnees = $req->fetch())
   {
     $client= new Client($donnees['id_client'],$donnees['nom'],$donnees['adresse'],$donnees['cp'],$donnees['ville'],$donnees['tel'],$donnees['date_facture']);
   }
   $req->closeCursor();
     
	return $client;
  
    
}