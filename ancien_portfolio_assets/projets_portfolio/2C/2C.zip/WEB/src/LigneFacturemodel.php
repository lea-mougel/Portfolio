<?php

require_once("myparam.inc.php");
require_once("classes/LigneFactureClass.php");

function getLigneFacture($num_facture){

    // Connexion à la base de données
    try
    {
        $bdd = new PDO('pgsql:host='.HOST.';dbname=cartouche', USER, PASS);
    }
    catch(Exception $e){
          die( 'Erreur : '.$e->getMessage()   );
    }

    // On récupère les factures
    $requete = "SELECT * FROM detail_facture where id_facture=".$num_facture.";";
    $req = $bdd->query($requete);
    
    if(!$req){
        $mesErreurs = $bdd->errorInfo();
        die("lecture impossible");
    }
   
    // initialisation des instances

   while ($donnees = $req->fetch())
   {
     $ligne = new LigneFacture($donnees['id_facture'],$donnees['reference'],$donnees['designation'],$donnees['type'],$donnees['quantite'],$donnees['tarif_facture'],$donnees['total_ligne_ht']);
     $tabLigneFacture[] = $ligne;
   }
   $req->closeCursor();
     
	return $tabLigneFacture;
  
    
}
