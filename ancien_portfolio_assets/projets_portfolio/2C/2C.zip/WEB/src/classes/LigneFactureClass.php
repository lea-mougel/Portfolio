<?php

class LigneFacture{
	private int $numero_facture;
	private string $reference;
	private string $designation;
	private string $type_c;
	private int $quantite;
	private float $tarif_facture;
	private float $total_ligne_ht;

	/*Constructeur*/
	public function __construct(int $numero_facture=null,string $reference="",string $designation="",string $type="",int $quantite=null,float $tarif_facture=null, float $total_ligne_ht=null){
			$this->setNumero_facture($numero_facture);
			$this->setReference($reference);
			$this->setDesignation($designation);
			$this->setType($type);
			$this->setQuantite($quantite);
			$this->setTarif_facture($tarif_facture);
			$this->setTotal_ligne_ht($total_ligne_ht);

	}
	
	/*Set et Get*/
	public function setNumero_facture(int $numero_f=null){
		if(!empty($numero_f)){
			$this->numero_facture=$numero_f;		
		}
	}
	public function getNumero_facture() {
		return($this->numero_facture);	
	}
	
	
	public function setReference(string $reference=""){
		if(!empty($reference)){
			$this->reference=$reference;		
		}
	}
	public function getReference() {
		return($this->reference);	
	}
	
	public function setDesignation(string $designation=""){
		if(!empty($designation)){
			$this->designation=$designation;		
		}
	}
	public function getDesignation() {
		return($this->designation);	
	}
	
	public function setType(string $type=""){
		if(!empty($type)){
			$this->type_c=$type;		
		}
	}
	public function getType() {
		return($this->type_c);	
	}
	
	public function setQuantite(int $quantite=null){
		if(!empty($quantite)){
			$this->quantite=$quantite;		
		}
	}
	public function getQuantite() {
		return($this->quantite);	
	}
	
	public function setTarif_facture(float $tarif_facture=null){
		if(!empty($tarif_facture)){
			$this->tarif_facture=$tarif_facture;		
		}
	}
	public function getTarif_facture() {
		return($this->tarif_facture);	
	}
	
	public function setTotal_ligne_ht(float $total_ligne_ht=null){
		if(!empty($total_ligne_ht)){
			$this->total_ligne_ht=$total_ligne_ht;		
		}
	}
	public function getTotal_ligne_ht() {
		return($this->total_ligne_ht);	
	}
}



?>