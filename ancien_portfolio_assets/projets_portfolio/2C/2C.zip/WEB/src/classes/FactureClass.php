<?php
require_once("ClientClass.php");
require_once("LigneFactureClass.php");

class Facture{
	private int $numero;
	private string $date_f;
	private Client $client;
	private $liste_ligneFacture=array();

	public function __construct(int $numero=null,string $date_f=""){
			$this->setNumero($numero);
			$this->setDate($date_f);
	}
	
	public function setNumero(int $numero=null){
		if(!empty($numero)){
			$this->numero=$numero;		
		}
	}
	public function getNumero() {
		return($this->numero);	
	}
	
	public function setDate(string $date_f=""){
		if(!empty($date_f)){
			$this->date_f=$date_f;		
		}
	}
	public function getDate() {
		return($this->date_f);	
	}
	
	public function setClient_f(Client $client=null) {
		if(!empty($client)){
			$this->client=$client;
		}
	}
	public function getClient_f(){
		return($this->client);
	}	
	
	public function setListe_ligneFacture(array $liste_ligneFacture=null) {
		if(!empty($liste_ligneFacture)){
			$this->liste_ligneFacture=$liste_ligneFacture;		
		}	
	}
	public function addListe_ligneFacture(LigneFacture $ligne=null) {
		if(!empty($ligne)){
			$this->liste_ligneFacture[]=$ligne;		
		}	
	}
	public function delListe_ligneFacture(LigneFacture $ligne=null) {
		for($i=0;$i<sizeof($this->liste_ligneFacture);$i++){
			if($this->liste_ligneFacture[$i]==$ligne){
				unset($this->liste_ligneFacture[$i]);
			}	
		}
	}
	public function getListe_ligneFacture() {
		return($this->liste_ligneFacture);
	}
}


?>