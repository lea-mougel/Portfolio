<?php
require_once("FactureClass.php");
class Entreprise{
	private string $nom;
	private string $adresse;
	private string $code_postal;
	private string $ville;
	private string $tel;
	private $liste_factures=array();
	

	public function __construct(string $nom="",string $adr="",string $cp="",string $ville="",string $tel=""){
			$this->setNom($nom);
			$this->setAdresse($adr);
			$this->setCode_postal($cp);
			$this->setVille($ville);
			$this->setTel($tel);
	}
	public function setNom(string $nom=""){
		if(!empty($nom)){
			$this->nom=$nom;		
		}
	}
	public function getNom() {
		return($this->nom);	
	}
	
	public function setAdresse(string $adr=""){
		if(!empty($adr)){
			$this->adresse=$adr;		
		}
	}
	public function getAdresse() {
		return($this->adresse);	
	}
	
	public function setCode_postal(string $cp=""){
		if(!empty($cp)){
			$this->code_postal=$cp;		
		}
	}
	public function getCode_postal() {
		return($this->code_postal);	
	}	
	
	public function setVille(string $ville=""){
		if(!empty($ville)){
			$this->ville=$ville;		
		}	
	}
	public function getVille() {
		return($this->ville);	
	}	
	
	public function setTel(string $tel=""){
		if(!empty($tel)){
			$this->tel=$tel;		
		}	
	}
	public function getTel() {
		return($this->tel);	
	}
	
	public function setListe_factures(array $liste_factures=null) {
		if(!empty($liste_factures)){
			$this->liste_factures=$liste_factures;		
		}	
	}
	public function addListe_factures(Facture $facture=null) {
		if(!empty($facture)){
			$this->liste_factures[]=$facture;		
		}	
	}
	public function delListe_factures(Facture $facture=null) {
		for($i=0;$i<sizeof($this->liste_factures);$i++){
			if($this->liste_factures[$i]==$facture){
				unset($this->liste_factures[$i]);
			}	
		}
	}
	public function getListe_factures() {
		return($this->liste_factures);
	}
}


?>