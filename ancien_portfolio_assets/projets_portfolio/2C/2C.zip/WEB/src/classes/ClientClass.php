<?php

class Client{
	private int $num_c;
	private string $nom;
	private string $adresse;
	private string $code_postal;
	private string $ville;
	private string $tel;
	private string $date_facture;
	
	//Constructeur
	public function __construct(int $num_c=null,string $nom_c="",string $adr_c="",string $cp_c="",string $ville_c="",string $tel_c="",string $date_facture=""){
			$this->setNumC($num_c);
			$this->setNomC($nom_c);
			$this->setAdresseC($adr_c);
			$this->setCode_postalC($cp_c);
			$this->setVilleC($ville_c);
			$this->setTelC($tel_c);
			$this->setDate_facture($date_facture);
	}
	//Set et Get
	public function setNumC(string $num_c=""){
		if(!empty($num_c)){
			$this->num_c=$num_c;		
		}
	}
	public function getNumC() {
		return($this->num_c);	
	}
	
	public function setNomC(string $nom_c=""){
		if(!empty($nom_c)){
			$this->nom=$nom_c;		
		}
	}
	public function getNomC() {
		return($this->nom);	
	}
	
	public function setAdresseC(string $adr_c=""){
		if(!empty($adr_c)){
			$this->adresse=$adr_c;		
		}
	}
	public function getAdresseC() {
		return($this->adresse);	
	}
	
	public function setCode_postalC(string $cp_c=""){
		if(!empty($cp_c)){
			$this->code_postal=$cp_c;		
		}
	}
	public function getCode_postalC() {
		return($this->code_postal);	
	}	
	
	public function setVilleC(string $ville_c=""){
		if(!empty($ville_c)){
			$this->ville=$ville_c;		
		}	
	}
	public function getVilleC() {
		return($this->ville);	
	}	
	
	public function setTelC(string $tel_c=""){
		if(!empty($tel_c)){
			$this->tel=$tel_c;		
		}	
	}
	public function getTelC() {
		return($this->tel);	
	}
	public function setDate_facture(string $date_facture=null){
		if(!empty($date_facture)){
			$this->date_facture=$date_facture;		
		}
	}
	public function getDate_facture() {
		return($this->date_facture);	
	}
}


?>