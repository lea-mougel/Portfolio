<?php
	define("HOST","127.0.0.1");
	//define("USER","cartouche_user");
	define("USER","cartouche_admin");
	//define("PASS","user"); 
	define("PASS","admin"); 
