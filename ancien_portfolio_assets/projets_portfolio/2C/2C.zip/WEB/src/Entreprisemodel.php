<?php

require_once("Facturemodel.php");
require_once("classes/EntrepriseClass.php");


function getEntreprise(){
	global $CC;
	$tabFactures=getFactures();
	$CC=new Entreprise("CHAMPAGNE CARTOUCHE","10 rue de l'encre","51100","REIMS","03.26.12.34.56");
	$CC->setListe_factures($tabFactures);
	return $CC;
};
