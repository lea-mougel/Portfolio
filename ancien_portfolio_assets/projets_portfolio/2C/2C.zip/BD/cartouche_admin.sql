create database cartouche;
create role cartouche_admin password 'admin' login;
grant all on database cartouche to cartouche_admin;

create role cartouche_user password 'user' login;
grant all on liste_facture  to cartouche_user;
grant all on detail_facture to cartouche_user;
grant all on detail_client to cartouche_user;

revoke all on function determinetariffacture from public;
grant execute on function determinetariffacture to cartouche_user;