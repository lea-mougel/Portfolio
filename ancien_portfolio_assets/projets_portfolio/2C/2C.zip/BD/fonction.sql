

CREATE OR REPLACE FUNCTION DetermineTarifFacture(varquantite integer,varclient int,varreference char(5),vartype char(1)) returns decimal(9,2) as $$ 
declare vartarif decimal(9,2);
		  tarif_contrat decimal(9,2);
		  quantite_contrat decimal(9,2);
		  prix_tarif decimal(9,2);
		  regulier integer;
begin
	SELECT INTO prix_tarif tarif
	FROM cartouche join cartouche_typee on cartouche_typee.reference=cartouche.reference
	where cartouche_typee.reference=varreference and cartouche_typee.type=type;
	
	SELECT INTO regulier count(id_client) 
	from client_regulier 
	where id_client=varclient;
	IF(regulier>0)
	then
		SELECT INTO tarif_contrat concerner.tarif
		from concerner join cartouche_typee on (cartouche_typee.reference=concerner.reference and cartouche_typee.type=concerner.type)
						  	join contrat on concerner.id_contrat=contrat.id_contrat
		where contrat.id_client=varclient and cartouche_typee.reference=varreference and cartouche_typee.type=vartype;
		SELECT INTO quantite_contrat quantite_mini
		from concerner join cartouche_typee on (cartouche_typee.reference=concerner.reference and cartouche_typee.type=concerner.type)
						  	join contrat on concerner.id_contrat=contrat.id_contrat
		where contrat.id_client=varclient and cartouche_typee.reference=varreference and cartouche_typee.type=vartype;
		
		IF(varquantite>=quantite_contrat)
		THEN
			vartarif=tarif_contrat;
		ELSE
			vartarif=prix_tarif;
		END IF;
	ELSE
		vartarif=prix_tarif;
	END IF;
	return(vartarif);
end;
$$ language 'plpgsql';

/*
CREATE OR REPLACE FUNCTION DetermineTarifFacture(varquantite integer,varclient int,varreference char(5),vartype char(1)) returns decimal(9,2) as $$ 
declare vartarif decimal(9,2);
		  tarif_contrat decimal(9,2);
		  quantite_contrat decimal(9,2);
		  prix_tarif decimal(9,2);
		  regulier integer;
begin
	SELECT INTO prix_tarif tarif
	FROM cartouche join cartouche_typee on cartouche_typee.reference=cartouche.reference
	where cartouche_typee.reference=varreference and cartouche_typee.type=type;
	
	SELECT INTO regulier count(id_client) 
	from client_regulier 
	where id_client=varclient;
	IF(regulier>0)
	then
		SELECT INTO tarif_contrat concerner.tarif
		from concerner join cartouche_typee on (cartouche_typee.reference=concerner.reference and cartouche_typee.type=concerner.type)
						  	join contrat on concerner.id_contrat=contrat.id_contrat
		where contrat.id_client=varclient and cartouche_typee.reference=varreference and cartouche_typee.type=vartype;
		SELECT INTO quantite_contrat quantite_mini
		from concerner join cartouche_typee on (cartouche_typee.reference=concerner.reference and cartouche_typee.type=concerner.type)
						  	join contrat on concerner.id_contrat=contrat.id_contrat
		where contrat.id_client=varclient and cartouche_typee.reference=varreference and cartouche_typee.type=vartype;
		
		IF(varquantite>=quantite_contrat)
		THEN
			vartarif=varquantite*tarif_contrat;
		ELSE
			vartarif=varquantite*prix_tarif;
		END IF;
	ELSE
		vartarif=varquantite*prix_tarif;
	END IF;
	return(vartarif);
end;
$$ language 'plpgsql';



*/