/*liste des facture : n°,date,nom,*/
CREATE VIEW liste_facture 
as
SELECT id_facture, date_facture, nom
FROM facture join client on facture.id_client=client.id_client
ORDER BY id_facture DESC;

/*detail client*/
CREATE VIEW detail_client
as
SELECT client.id_client, nom, adresse,cp,ville,tel,date_facture,id_facture
from client join facture on facture.id_client=client.id_client;


/*detail d'une facture : reference,designation,type,quantite,tarif,total_HT*/
CREATE VIEW detail_facture
as
SELECT id_facture,cartouche_typee.reference,designation,cartouche_typee.type,quantite,tarif,tarif*quantite as "total_ligne_ht"
FROM cartouche_typee join facturer on (cartouche_typee.reference=facturer.reference and cartouche_typee.type=facturer.type)
							join cartouche on cartouche_typee.reference=cartouche.reference;
							
/*detail d'une facture bonne version*/
CREATE VIEW detail_facture
as
SELECT facture.id_facture,cartouche_typee.reference,designation,cartouche_typee.type,quantite,DetermineTarifFacture(facturer.quantite, facture.id_client, cartouche_typee.reference, cartouche_typee.type) as "tarif_facture",DetermineTarifFacture(facturer.quantite, facture.id_client, cartouche_typee.reference, cartouche_typee.type)*quantite as "total_ligne_ht"
FROM cartouche_typee join facturer on (cartouche_typee.reference=facturer.reference and cartouche_typee.type=facturer.type)
							join facture on facture.id_facture=facturer.id_facture
							join cartouche on cartouche_typee.reference=cartouche.reference;