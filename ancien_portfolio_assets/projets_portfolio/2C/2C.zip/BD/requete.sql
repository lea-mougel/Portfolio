/*VERIFICATION DES CONTRAINTES*/
/*1. Une cartouche avec un tarif négatif. 
  2. Un client sans nom
  3. Un contrat avec une durée du contrat de 50 jours
  4. Une facture avec une quantité facturée négative. Une facture avec une quantité facturée de 2000. 
  5. Un contrat avec une quantité minimale négociée négative. Un contrat avec une quantité minimale négociée de 2000. 
  6. Un client régulier avec un nom de contact identique à celui du nom du client. (cette contrainte n’est pas bloquante. Vous vérifierez que le nom de contact est bien vide dans ce cas)
*/
/*1*/
INSERT INTO cartouche_typee VALUES ('B40L','R',-42);

/*2*/
INSERT INTO client (id_client,nom, adresse, cp, ville, tel) values (6,null,'test','51100','REIMS','0102030405');

/*3*/
INSERT INTO contrat VALUES (4,'2021-01-01',50,3);	

/*4*/
INSERT INTO facturer(id_facture, reference, type, quantite) values (131, 'B60L','R', -5);
INSERT INTO facturer(id_facture, reference, type, quantite) values (131, 'HPXR','N', 2000);

/*5*/
INSERT INTO concerner VALUES ('B204','N',1,-5,78.40);
INSERT INTO concerner VALUES ('B204','N',1,2000,78.40);

/*6*/
begin transaction;
INSERT INTO client_regulier VALUES(1,'DUMOTIER Philippe');
SELECT * FROM client_regulier;

/*affichage id_facure,date,nom*/
SELECT id_facture, date_facture, nom
FROM facture join client on facture.id_client=client.id_client;

/*affichage ref, designation, type, quantite , tarif pour facture n°124*/
SELECT cartouche_typee.reference,designation,cartouche_typee.type,quantite,tarif 
FROM cartouche_typee join facturer on (cartouche_typee.reference=facturer.reference and cartouche_typee.type=facturer.type)
							join cartouche on cartouche_typee.reference=cartouche.reference
where id_facture=124;

/*affichage ref, designation, type, quantite , tarif, total ht pr chaque ligne pour facture n°124*/
SELECT cartouche_typee.reference,designation,cartouche_typee.type,quantite,tarif,tarif*quantite as "total_ligne_ht"
FROM cartouche_typee join facturer on (cartouche_typee.reference=facturer.reference and cartouche_typee.type=facturer.type)
							join cartouche on cartouche_typee.reference=cartouche.reference
where id_facture=124;

/*REQUETE A : client ayant un contrat + quantite/prix nego*/
SELECT client_regulier.id_client,quantite_mini,tarif,reference,type
from client_regulier join contrat on contrat.id_client=client_regulier.id_client
	                  join concerner on concerner.id_contrat=contrat.id_contrat;

/*REQUETE B : pour reference B204 de type N, client 3*/
SELECT date_facture,cartouche_typee.reference,designation,cartouche_typee.type,facturer.quantite,cartouche_typee.tarif,quantite_mini,concerner.tarif,cartouche_typee.tarif*quantite as "total_ligne_ht"
from cartouche_typee join facturer on (cartouche_typee.reference=facturer.reference and cartouche_typee.type=facturer.type)
							join facture on  facture.id_facture=facturer.id_facture
							join cartouche on cartouche.reference=cartouche_typee.reference
							join concerner on (cartouche_typee.reference=concerner.reference and cartouche_typee.type=concerner.type)
where facture.id_client=3 and cartouche_typee.reference='B204' and cartouche_typee.type='N';


/*REQUETE B NEW: pour reference B204 de type N, client 3*/
SELECT date_facture,cartouche_typee.reference,designation,cartouche_typee.type,facturer.quantite,DetermineTarifFacture(facturer.quantite, facture.id_client, cartouche_typee.reference, cartouche_typee.type) as "tarif facturé",quantite_mini,concerner.tarif,facturer.quantite*DetermineTarifFacture(facturer.quantite, facture.id_client, cartouche_typee.reference, cartouche_typee.type) as "total_ligne_ht"
from cartouche_typee join facturer on (cartouche_typee.reference=facturer.reference and cartouche_typee.type=facturer.type)
							join facture on  facture.id_facture=facturer.id_facture
							join cartouche on cartouche.reference=cartouche_typee.reference
							join concerner on (cartouche_typee.reference=concerner.reference and cartouche_typee.type=concerner.type)

where facture.id_client=3 and cartouche_typee.reference='B204' and cartouche_typee.type='N';

/*test : ne fonctionne pas*/
SELECT date_facture,cartouche_typee.reference,designation,cartouche_typee.type,facturer.quantite,DetermineTarifFacture(facturer.quantite, contrat.id_client, cartouche_typee.reference, cartouche_typee.type) as "tarif_facture",quantite_mini,concerner.tarif,facturer.quantite*tarif_facture as "total_ligne_ht"
from cartouche_typee join facturer on (cartouche_typee.reference=facturer.reference and cartouche_typee.type=facturer.type)
							join facture on  facture.id_facture=facturer.id_facture
							join cartouche on cartouche.reference=cartouche_typee.reference
							join concerner on (cartouche_typee.reference=concerner.reference and cartouche_typee.type=concerner.type)
							join contrat on concerner.id_contrat=contrat.id_contrat
where contrat.id_client=3 and cartouche_typee.reference='B204' and cartouche_typee.type='N';