
/*PROSPECT*/
/*CREATE DATABASE prospect;*/

DROP TABLE IF EXISTS employe CASCADE;
DROP TABLE IF EXISTS entreprise CASCADE;
DROP TABLE IF EXISTS prospecter CASCADE;

CREATE TABLE employe(
	num_emp INT PRIMARY KEY,
	nom VARCHAR(50) NOT NULL,
	prenom VARCHAR(50) NOT NULL,
	salaire DECIMAL(9,2) CHECK(salaire>0)
);

CREATE TABLE entreprise(
	code_e CHAR(1) PRIMARY KEY,
	raison_sociale VARCHAR(50),
	adresse VARCHAR(50),
	cp CHAR(5),
	ville VARCHAR(50)
);

CREATE TABLE prospecter(
	num_emp INT,
	code_e CHAR(1),
	date_ date,
	notes VARCHAR(150),
	PRIMARY KEY (num_emp,code_e,date_),
	FOREIGN KEY (num_emp) REFERENCES employe (num_emp),
	FOREIGN KEY (code_e) REFERENCES entreprise (code_e)
);

INSERT INTO employe VALUES(1,'Dupond','Pierre');
INSERT INTO entreprise VALUES('A');
INSERT INTO entreprise VALUES('B');
INSERT INTO entreprise VALUES('C');

INSERT INTO prospecter VALUES(1,'A','21/11/2023'); 
INSERT INTO prospecter VALUES(1,'B','21/11/2023'); 
INSERT INTO prospecter VALUES(1,'A','22/11/2023'); 
INSERT INTO prospecter VALUES(1,'C','22/11/2023'); 


/*GRAND PRIX*/
/*CREATE DATABASE grand_prix;*/

DROP TABLE IF EXISTS grand_prix CASCADE;
DROP TABLE IF EXISTS pilote CASCADE;
DROP TABLE IF EXISTS place CASCADE;
DROP TABLE IF EXISTS participation CASCADE;

CREATE TABLE grand_prix(
	code_gp INT PRIMARY KEY,
	nom_gp VARCHAR(50),
	nb_tours INT,
	longueur INT
);

CREATE TABLE pilote(
	code_pilote CHAR(1) PRIMARY KEY,
	nom VARCHAR(50),
	prenom VARCHAR(50),
	dat_naiss DATE
);

CREATE TABLE place(
	code_place INT PRIMARY KEY,
	points INT
);

CREATE TABLE participation(
	code_gp INT,
	code_pilote CHAR(1),
	code_place INT,
	nb_tours INT,
	tps INT,
	PRIMARY KEY (code_gp,code_pilote),
	FOREIGN KEY (code_gp) REFERENCES grand_prix (code_gp),
	FOREIGN KEY (code_pilote) REFERENCES pilote (code_pilote),
	FOREIGN KEY (code_place) REFERENCES place (code_place)
);

/*verifier si la place est déjà attribuée*/
create or replace function f_verif_place() returns trigger as $verif_place$
declare nb_place INT; /*va recevoir le nombre de ligne recu par la requete*/
begin
	SELECT into nb_place count(code_place) 
	from participation
	where code_place=NEW.code_place and code_gp=NEW.code_gp;
	IF(nb_place>0) THEN
		raise exception 'Cette place est déjà attribué';
	END IF;
	return NEW;
end;
$verif_place$ language 'plpgsql';

DROP TRIGGER IF EXISTS verif_place  ON participation;

CREATE TRIGGER verif_place BEFORE INSERT ON participation
FOR EACH ROW 
EXECUTE PROCEDURE f_verif_place();


INSERT INTO grand_prix VALUES (1,'Grand prix de Monaco');
INSERT INTO pilote VALUES ('A');
INSERT INTO pilote VALUES ('B');
INSERT INTO pilote VALUES ('C');
INSERT INTO place VALUES(1);
INSERT INTO place VALUES(2);
INSERT INTO place VALUES(3);

INSERT INTO participation VALUES(1,'A',1);
INSERT INTO participation VALUES(1,'B',2);
/*INSERT INTO participation VALUES(1,'C',1);
INSERT INTO participation VALUES(1,'A',3);*/




