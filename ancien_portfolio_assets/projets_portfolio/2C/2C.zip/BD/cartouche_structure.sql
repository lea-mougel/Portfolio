CREATE TABLE client(
   id_client INT,
   nom VARCHAR(100) NOT NULL, /*nom du client obligatoire*/
   adresse VARCHAR(200),
   cp CHAR(5),
   ville VARCHAR(50),
   tel VARCHAR(13),
   PRIMARY KEY(id_client)
);

CREATE TABLE cartouche(
   reference CHAR(5),
   designation VARCHAR(150),
   PRIMARY KEY(reference)
);

CREATE TABLE cartouche_typee(
   reference CHAR(5),
   type CHAR(1),
   tarif DECIMAL(9,2) CHECK(tarif>0), /*tarif strictement positif*/
   PRIMARY KEY(reference, type),
   FOREIGN KEY(reference) REFERENCES cartouche(reference)
);


CREATE TABLE client_regulier(
   id_client INT,
   nom_contact VARCHAR(50) ,
   PRIMARY KEY(id_client),
   FOREIGN KEY(id_client) REFERENCES client(id_client)
);

CREATE TABLE client_occasionnel(
   id_client INT,
   PRIMARY KEY(id_client),
   FOREIGN KEY(id_client) REFERENCES client(id_client)
);

CREATE TABLE facture(
   id_facture INT,
   date_facture DATE,
   id_client INT NOT NULL,
   PRIMARY KEY(id_facture),
   FOREIGN KEY(id_client) REFERENCES client(id_client)
);

CREATE TABLE avoir(
   id_avoir INT,
   date_avoir DATE,
   id_facture INT NOT NULL,
   PRIMARY KEY(id_avoir),
   FOREIGN KEY(id_facture) REFERENCES facture(id_facture)
);

CREATE TABLE contrat(
   id_contrat INT,
   date_contrat DATE,
   duree INT  CHECK((duree=60) or (duree=90)),/*durée du contrat 60 jours ou 90 jours*/
   id_client INT NOT NULL,
   PRIMARY KEY(id_contrat),
   FOREIGN KEY(id_client) REFERENCES client_regulier(id_client)
);

CREATE TABLE concerner(
   reference CHAR(5),
   type CHAR(1),
   id_contrat INT,
   quantite_mini INT CHECK(quantite_mini>0 and quantite_mini<=1000), /*quantite strictement positive et  jamais au-dessus de 1000 */
   tarif DECIMAL(9,2) CHECK(tarif>0),/*tarif strictement positif*/
   PRIMARY KEY(reference, type, id_contrat),
   FOREIGN KEY(reference, type) REFERENCES cartouche_typee(reference, type),
   FOREIGN KEY(id_contrat) REFERENCES contrat(id_contrat)
);

CREATE TABLE facturer(
   reference CHAR(5),
   type CHAR(1),
   id_facture INT,
   quantite INT CHECK(quantite>0 and quantite<=1000), /*quantite strictement positive et  jamais au-dessus de 1000 */
   PRIMARY KEY(reference, type, id_facture),
   FOREIGN KEY(reference, type) REFERENCES cartouche_typee(reference, type),
   FOREIGN KEY(id_facture) REFERENCES facture(id_facture)
);

CREATE TABLE deduire(
   id_facture INT,
   id_avoir INT,
   PRIMARY KEY(id_facture, id_avoir),
   FOREIGN KEY(id_facture) REFERENCES facture(id_facture),
   FOREIGN KEY(id_avoir) REFERENCES avoir(id_avoir)
);

/*verifier que le nom de contact est différent du nom du client*/
create or replace function f_verif_nom_contact() returns trigger as $verif_nom_contact$
declare varcontact client.nom%type; /*client.nom%type renvoit le type de la colonne nom de la table client*/
begin
	SELECT into varcontact nom 
	from client 
	where id_client=NEW.id_client;
	IF(NEW.nom_contact=varcontact) THEN
		NEW.nom_contact='';
	END IF;
	return NEW;
end;
$verif_nom_contact$ language 'plpgsql';
DROP TRIGGER IF EXISTS verif_nom_contact  ON client_regulier;

CREATE TRIGGER verif_nom_contact BEFORE INSERT ON client_regulier
FOR EACH ROW 
EXECUTE PROCEDURE f_verif_nom_contact();



