<?php

echo "<!DOCTYPE html>
<html>
<head>
	<meta charset='utf-8' />
	<title> Accueil </title>
	<link href='foot.css' rel='stylesheet' type='text/css'>
</head>
<body id='page1'>
	<header>
		<h1 class='titrepage'> Accueil </h1>
		<div class='button'>
			<a href='matchs.php'> Les matchs </a>
			<a href='joueurs.php'> Présentation des joueurs et des équipes</a>

		</div>
	</header>

</body>
</html>"





?>