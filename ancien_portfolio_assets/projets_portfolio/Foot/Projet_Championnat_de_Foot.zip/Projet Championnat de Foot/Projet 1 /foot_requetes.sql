
/*Requête n°1: Match de la première journée*/

Select date as "Date du match", home as "Equipe qui reçoit",  away as "Equipe qui se déplace", stage as "Journée" 
from Match
where stage=1;

/*Requête n°2: Liste des équipes*/

SELECT name 
from Team;

/*Requête n°3: Match de la première journée avec nom de l'équipe qui reçoit*/

SELECT date, name as "Nom de l'équipe qui reçoit"
from match join Team on team.id=home
where stage=1;

/*Requête n°4: Match de la première journée avec nom de l'équipe qui reçoit et celle qui se déplace*/

SELECT date, H.name as "Nom de l'équipe qui reçoit" , A.name as "Nom de l'équipe qui se déplace" 
from match join Team H on H.id=home
			  join Team A on A.id=away
where stage=1;

/*Requête n°5: Créer vue : "LesRencontres" */

create view LesRencontres
as
SELECT date, H.name as "Nom de l'équipe qui reçoit" , A.name as "Nom de l'équipe qui se déplace" 
from match join Team H on H.id=home
			  join Team A on A.id=away;
			  
/*Requête n°6: Types d'évenements */

Select * from typ_Event;

/*Requête n°7: nom du ou des équipes créées en 1881*/

Select name
from team 
where birthday='1881';

/*Requête n°8:  Nom + date de création des équipes du plus ancien au plus récent*/

Select name, birthday
from team
order by birthday ;

/*Requête n°9: nom de l'équipe de Zlatan*/

Select distinct player.name , team.name
from player join event on player.id=event.player
				join team on event.team=team.id
where player.name LIKE 'Zlatan%';

/*Requête n°10: nombre d'équipe*/

SELECT count(*)
from team;

/*Requête n°11: nombre de matchs disputés*/

select count(*)
from match;

/*Requête n°12: nombre de buts sur penalty (jointures uniquement)*/

select count(*)
from event join typ_event on typ_event.id=event.type
where lib='but sur penalty';

/*Requête n°13: nombre de cartons rouges (sous-requêtes uniquement)*/

select count(*)
from event 
where type=(select id
				from typ_event 
				where lib='carton rouge');

/*Requête n°14: nombre de penalty */

/*jointures*/

select count(*)
from event join typ_event on typ_event.id=event.type
where lib='but sur penalty' or lib='penalty raté';

/*sous-requêtes*/

select count(*)
from event 
where type IN (select id
					from typ_event 
					where lib='but sur penalty' or lib='penalty raté');
				
/*Requête n°15: nombre de buts*/
	
select count(*)
from event join typ_event on typ_event.id=event.type
where lib='but sur penalty' or lib='but' or lib='but contre son camp';			
				
/*Requête n°16: nombre de buts par équipe*/

/*la requête*/

select team, count(*)
from event join typ_event on typ_event.id=event.type
where lib='but sur penalty' or lib='but' or lib='but contre son camp'
group by team
order by team;	


/*création de la vue*/

create view nombreDeButParEquipe
as 
select team, count(*)
from event join typ_event on typ_event.id=event.type
where lib='but sur penalty' or lib='but' or lib='but contre son camp'
group by team
order by team;	
/*Requête pour vérifier*/

select *
from nombreDeButParEquipe;

/*Requête n°17: 10 cartons rouges obtenus le plus rapidement*/

Select event.id, match, time, player, team, type
from event join typ_event on typ_event.id=event.type
where lib='carton rouge'
order by time
limit 10;

/*Requête n°18: Date de création la plus ancienne des équipes*/

select min(birthday)
from team;

/*Requête n°19: Afficher la team la plus ancienne*/

select *
from team 
where birthday =(select min(birthday) from team);

/*Requête n°20: clé primaire de l'équipe de Lorient*/

select id
from team 
where city='Lorient';

/*Requête n°21: nombre de but de Lorient */

Select * 
from nombreDeButParEquipe
where team=18;
/*
Select * 
from nombreDeButParEquipe
where team=(select id from team where city='Lorient');*/


/*Requête n°22: nombre de but de Lorient à l'exterieur*/
 
select count(*)
from event join typ_event on typ_event.id=event.type
			  join team on team.id=team
			  join match on match.id=match
where (lib='but sur penalty' or lib='but' or lib='but contre son camp' ) and team.city='Lorient' and away=18;	

/*Requête n°23: Nombre de buts encaissés par Lorient*/

select  count(*)
from event join typ_event on typ_event.id=event.type
			  join team on team.id=team
			  join match on match.id=match
where (lib='but sur penalty' or lib='but' or lib='but contre son camp' ) and team.city!='Lorient' and (home=18 or away=18);


/*Requête n°24: Nombre de buts encaissés par Lorient à domicile*/

select  count(*)
from event join typ_event on typ_event.id=event.type
			  join team on team.id=team
			  join match on match.id=match
where (lib='but sur penalty' or lib='but' or lib='but contre son camp' ) and team.city!='Lorient' and home=18;

/*Requête n°25: Nombre de buts marqué pendant la première moitié de la saison*/

select count(*)
from event join typ_event on typ_event.id=event.type
			  join team on team.id=team
			  join match on match.id=match
where (lib='but sur penalty' or lib='but' or lib='but contre son camp' ) and team.city='Lorient' and stage <= 19 ;	


/*Requête n°26: but le plus rapide*/

Select  time
from event join typ_event on typ_event.id=event.type
where lib='but sur penalty' or lib='but' or lib='but contre son camp' 
order by time
limit 1;

/*Requête n°27: le ou les buts marqués à la troisième minute*/

Select  time, player.name
from event join typ_event on typ_event.id=event.type
			  join player on player=player.id
where (lib='but sur penalty' or lib='but' or lib='but contre son camp') and time=3
order by time;

/*Requête n°28: ajouter date du match*/

Select  time, player.name, date
from event join typ_event on typ_event.id=event.type
			  join player on player=player.id
			  join match on match=match.id
where (lib='but sur penalty' or lib='but' or lib='but contre son camp') and time=3
order by time;

/*Requête n°29: ajouter les équipes*/


Select  time, player.name, date ,H.name, A.name
from event join typ_event on typ_event.id=event.type
			  join player on player=player.id
			  join match on match=match.id
			  join Team H on H.id=home
			  join Team A on A.id=away
where (lib='but sur penalty' or lib='but' or lib='but contre son camp') and time=3
order by time;

/*Requête n°30: afficher seulement date du match , nom des équipes, jouer et minute du but*/

Select  date as "Date du match",H.name as "Equipe qui reçoit", A.name as "Equipe qui se déplace"  ,player.name as "Joueur" ,time as "Minute du but"
from event join typ_event on typ_event.id=event.type
			  join player on player=player.id
			  join match on match=match.id
			  join Team H on H.id=home
			  join Team A on A.id=away
where (lib='but sur penalty' or lib='but' or lib='but contre son camp') and time=3
order by time;


