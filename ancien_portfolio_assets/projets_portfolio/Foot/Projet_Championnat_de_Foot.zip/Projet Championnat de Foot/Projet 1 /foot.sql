DROP TABLE IF EXISTS Player CASCADE;
DROP TABLE IF EXISTS Team CASCADE;
DROP TABLE IF EXISTS Match CASCADE;
DROP TABLE IF EXISTS typ_Event CASCADE;
DROP TABLE IF EXISTS Event CASCADE;


CREATE TABLE Player(
   id INT,
   name VARCHAR(100) NOT NULL,
   birthday DATE NOT NULL,
   photo VARCHAR(300) ,
   PRIMARY KEY(id)
);

CREATE TABLE Team(
   id INT,
   name VARCHAR(100) NOT NULL,
   surname VARCHAR(100) NOT NULL,
   short VARCHAR(50) NOT NULL,
   birthday CHAR(4) NOT NULL,
   city VARCHAR(50) NOT NULL,
   photo VARCHAR(300) ,
   PRIMARY KEY(id)
);

CREATE TABLE Match(
   id INT,
   date DATE NOT NULL,
   home INT NOT NULL,
	away INT NOT NULL,
   stage INT NOT NULL,
   PRIMARY KEY(id),
   FOREIGN KEY(home) REFERENCES Team(id),
   FOREIGN KEY(away) REFERENCES Team(id)
);

CREATE TABLE typ_Event(
   id VARCHAR(50),
   lib VARCHAR(50) NOT NULL,
   PRIMARY KEY(id)
);

CREATE TABLE Event(
   id INT,
	match INT NOT NULL,
   time INT NOT NULL,
	player INT NOT NULL,
   team INT NOT NULL,
   type VARCHAR(50) NOT NULL,
	photo VARCHAR(300) ,
	video VARCHAR(300) ,
   PRIMARY KEY(id),
	FOREIGN KEY(match) REFERENCES Match(id),
	FOREIGN KEY(player) REFERENCES Player(id), 
	FOREIGN KEY(team) REFERENCES Team(id),
   FOREIGN KEY(type) REFERENCES typ_Event(id)
  
);

INSERT INTO typ_Event VALUES ('goal','but');
INSERT INTO typ_Event VALUES ('penalty','but sur penalty');
INSERT INTO typ_Event VALUES ('own','but contre son camp');
INSERT INTO typ_Event VALUES ('miss','penalty raté');
INSERT INTO typ_Event VALUES ('yellow','carton jaune');
INSERT INTO typ_Event VALUES ('yellow2','deuxième carton jaune');
INSERT INTO typ_Event VALUES ('red','carton rouge');



