

create view lesmatchs
as 		  
select team, match ,count(lib)
from event join typ_event on typ_event.id=event.type
where lib='but sur penalty' or lib='but' or lib='but contre son camp'
group by team,event.match
order by event.match;

/*lesjoueurs*/
create view lesjoueurs
as
select distinct player.name as "playername",player.photo, team.name as "teamname", team.short, team.birthday, team.city
from player join event on player.id=event.player
			   join team on event.team=team.id
order by team.name;