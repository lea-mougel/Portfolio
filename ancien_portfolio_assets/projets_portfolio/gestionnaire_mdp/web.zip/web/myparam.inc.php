<?php

	define('HOST','127.0.0.1');
	define('USER','leam');
	define('PASS','florian88330');
?>