<?php
include_once('myparam.inc.php');
session_start();

function connecte() {
	
	$conn=pg_connect('host='.HOST.' dbname=coffrefort user='.USER.' password='.PASS);
	if(!$conn)  {
		 die("Erreur de connexion".pg_last_error());
	}
	$sql ="select distinct app
			from applications;";
	   	
   $res = pg_query($conn, $sql);
   if(!$res){
      die("erreur dans la requête".pg_last_error());
   }
   $tab=pg_fetch_all($res);
  
	$texte="<fieldset> <form action='page_modif.php' method='post'>
	<input type='submit' name='modification' value='Modifier son mdp'></form>
	<form action='accueil.php' method='post'>
	<input type='submit' name='envoi' value='LOGOUT'> </form></fieldset>
	<h2> Vous êtes connecté </h2>
	<form action='accueil.php' method='post'>
	Ajouter un mot de passe: 
	<select name='sel_app'>";
	foreach($tab as $ligne){
		$texte.="<option value=".$ligne['app'].">".$ligne['app']."</option>";
	}
	$texte.="</select>
	<label> Identifiant : </label><input type='text' name='id_app'>
	<label> Mot de passe : </label><input type='text' name='mdp_app'>
	<input type='submit' value='Valider'> </form>";
	//possibilité de basculer le input mdp_app en type='pwd'
	pg_free_result($res);
	pg_close($conn);	
	return($texte);
}

function ajout_pass_app($maitre,$app,$id,$mdp){
	$conn=pg_connect('host='.HOST.' dbname=coffrefort user='.USER.' password='.PASS);
	if(!$conn)  {
		 die("Erreur de connexion".pg_last_error());
	}
	$sql_idapp ="SELECT id 
				 from applications 
				 where app='".$app."';";
	$res_idapp=pg_query($conn,$sql_idapp);
	if(!$res_idapp){
      die("erreur dans la requête select app".pg_last_error());
   }
   $arr=pg_fetch_array($res_idapp);
   $idapp=$arr[0];
   
   $sql_idmaitre="SELECT id 
				 from pass 
				 where pwd='".$maitre."';";
	$res_idmaitre=pg_query($conn,$sql_idmaitre);
	if(!$res_idmaitre){
      die("erreur dans la requête select maitre".pg_last_error());
   }
   $arr=pg_fetch_array($res_idmaitre);
   $idmaitre=$arr[0];

   $sql="INSERT INTO identifiant values(nextval('id_identifiant'),".$idapp.",".$idmaitre.",'".$id."','".$mdp."');";
   $res=pg_query($conn,$sql);
   if(!$res){
      die("erreur dans la requête insert".pg_last_error());
   }
   $texte='Identifiant et mot de passe ajouté';
   
   pg_free_result($res_idapp);
   pg_free_result($res_idmaitre);
   pg_free_result($res);
	pg_close($conn);
	return($texte);
}


?>
