<?php
session_start();

function modif($mdp,$modif,$input) {
		//fonction qui modifie la colonne demandée dans la base de données
		//$mdp = ancien mot de passe maitre  $modif= colonne à modifier  $input= nouvelle valeur

		$conn=pg_connect('host='.HOST.' dbname=coffrefort user='.USER.' password='.PASS);
		if(!$conn)  {
			 die("Erreur de connexion".pg_last_error());
		}
		
		$sql ="update pass 
				set ".$modif." = '".$input."'
		   	where  pwd= '".$mdp."' ;";
		   	
	    $req = pg_query($conn, $sql);
	   
	 
	    if(!$req){
	        die("erreur dans la requête".pg_last_error());
	     }
	    else{
			echo " Modification réussie ";		    
	    }
		pg_free_result($req);
		pg_close($conn);	
	}
	
	function supp($mdp2) {
		//fonction qui supprime le compte (mot de passe maître) de la base de donnée
		$conn2=pg_connect('host='.HOST.' dbname=coffrefort user='.USER.' password='.PASS);
		if(!$conn2)  {
			 die("Erreur de connexion".pg_last_error());
		}
		
		
		
		//sauvegarde dans la table histo
		$date=date('d/m/Y');
		$maitre=$mdp2;  //mot de passe maître
		
		//récupère chaque app qui a un id pour ce mot de passe maître
		              								
		$sql="SELECT distinct applications.app, pass.pwd, identifiant.name, identifiant.pwd
				from identifiant join applications on identifiant.app=applications.id
									  join pass on identifiant.maitre=pass.id
				where pass.pwd='".$maitre."';";
		$res=pg_query($conn2,$sql);
		if(!$res){
			die("Erreur de requête recup ".pg_last_error());
		}
		$app=pg_fetch_all($res);
		$insertHisto='';
		echo $app;
		foreach($app as $ligne){
			/*
			$insertHisto.="INSERT INTO histo values ('".$date."','".$ligne['pass.pwd']."','".$ligne['applications.app'].
			"','".$ligne['identifiant.name']."','".$ligne['identifiant.pwd']."');";*/
			$insertHisto.="INSERT INTO histo values ('".$date."','".$ligne[1]."','".$ligne[0].
			"','".$ligne[2]."','".$ligne[3]."');";
			echo $insertHisto;
		}
		/*var_dump($insertHisto);
		$res2=pg_query($conn2,$insertHisto);
		if(!$res2){
			die("Erreur de requête histo".pg_last_error());
		}		
		*/
		//Suppression du compte
		
		$sql2 ="DELETE FROM pass
		   	  where  pwd= '".$mdp2."' ;";
		   	
	   $req2 = pg_query($conn2, $sql2);
	   
	   if(!$req2){
	       die("erreur dans la requête".pg_last_error());
	   }
	   else{
			echo " Compte supprimé ";
			$_SESSION['connexion']=false;		    
	   }
		pg_free_result($res);
		pg_free_result($req2);
		pg_close($conn2);	
	}
	
	
	
?>


