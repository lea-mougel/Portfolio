<?php

session_start();

function formulaire_connexion(){
	$texte = "<fieldset>
	<form action='accueil.php' method='post'>";

	if($connexion==false) {
		$texte=$texte."
		<label> Mot de passe maître :</label> <input type='text' name='pwd'>
		<br>
		<input type='submit' name='envoi' value='ENVOYER'></form>
		
		<form action='page_creation.php' method='post'>
		<input type='submit' name='envoi' value='Créer son mot de passe'>
		</form>
		</fieldset>";
/*
		if(isset($_POST['pwd'])) {
			$texte=$texte. "<h1> Ce compte n'existe pas </h1>";
		}*/
	}
	else { 
		$texte=$texte."</fieldset> <br>";
	}
	return ($texte);
}



?>