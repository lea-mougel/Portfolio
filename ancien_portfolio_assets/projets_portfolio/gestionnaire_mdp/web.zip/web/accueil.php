<?php
include_once('fonctions.php');
include_once('formulaire_connexion.php');
include_once('verif.php');

session_start();

$html='<html> <body>';

if(!isset($_SESSION['connexion'])||$_POST['envoi']=='LOGOUT') {   //déconnexion
	$_SESSION['connexion']=false;
	session_unset();
}


if(isset($_POST['pwd'])){     //verification du mot de passe maître
	$verif_pwd=verif_pass($_POST['pwd']);
	$verif_user=verif_user($_POST['pwd']);
	if($verif_pwd==true && $verif_user==true) {
		$_SESSION['connexion']=true;
	}
	else {
		if($verif_pwd==false) {
			$html.='Mot de passe non valide'	;
		}
		if($verif_user==false){
			$html.=" Ce compte n'existe pas ";
		}
	}
}


if($_SESSION['connexion']==false) {
	
	$html.=formulaire_connexion();
}
if($_SESSION['connexion']==true ) {
	$html.=connecte();
	if(!isset($_SESSION['mdp'])) {
		$_SESSION['mdp']=$_POST['pwd'];
	}
}

if(isset($_POST['mdp_app'])) {   //si le mot de passe app est entré
	$verif_pass_app=verif_pass($_POST['mdp_app']);  //verification
}
else {
	$verif_pass_app=false;
}

if(isset($_POST['sel_app']) && isset($_POST['id_app']) && $verif_pass_app==true && isset($_SESSION['mdp'])){
	$html.=ajout_pass_app($_SESSION['mdp'],$_POST['sel_app'],$_POST['id_app'],$_POST['mdp_app']); //fonction dans fonctions.php
}

$html.='</body> </html>';

echo $html;

?>
