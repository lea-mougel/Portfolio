<?php 
include_once('myparam.inc.php');
include_once('verif.php');
include_once('fonctions_modif.php');

session_start();
		
$html="<html> <body>";
if(isset($_POST['sel_modif']) && isset($_POST['texte']) && !empty($_POST['texte'])) { 
		//Si une colonne à modifier sélectionnée, et si une valeur pour modifier est entrée
		
		if($_POST['sel_modif']=='pwd') { //si le mot de passe est à modifier
			$verif=verif_pass($_POST['texte']);		 //vérification du mot de passe entré
		}
		else {
			if($_POST['sel_modif']=='mail') {  //si le mail est à modifier
				$verif=verif_mail($_POST['texte']);	//vérification du mail entré
			}
			else {
				$verif=true;  // si telephone, on suppose que la valeur entrée est bonne
			}			
		}
		if($verif==true) {  //si aucun problème de vérification
			modif($_SESSION['mdp'],$_POST['sel_modif'],$_POST['texte']);
		}
		else {
			$html.="La valeur entrée n'est pas valide";			
		}
}
	if(isset($_SESSION['mdp'] ) && isset($_POST['val']) && $_POST['val']=='Modifier') { 
	//si la personne est connecté et que la personne à cliquer sur modifier
		$html.="<fieldset>	<form action='page_modif.php' method='post'>
		<label> Valeur à modifier :</label>
		<input type='radio' name='sel_modif' value='pwd'>  Mot de passe maître
		<input type='radio' name='sel_modif' value='mail'> Email
		<input type='radio' name='sel_modif' value='tel'> Téléphone <br>
		<label> Nouvelle valeur </label ><input type='text' name='texte' > <br>
		<input type='submit' name='validation' value='Valider'></form>";  
		
	}
	else {
		if(isset($_SESSION['mdp']) && $_POST['val']=='Supprimer') {	
			supp($_SESSION['mdp']);    //possibilité d'ajouter un bouton de confirmation
		}
	}
		
//sql + requete

	


	if(!isset($_POST['val'])){
		$html.=" <fieldset>	<form action='page_modif.php' method='post'>
		<input type='submit' name='val' value='Modifier'>
		<input type='submit' name='val' value='Supprimer'></form><br>";	
	}
	$html.="<form action='accueil.php'> 
			<input type='submit' name='envoi' value='Accueil'>
		</form>	</fieldset>
		</body> </html>";
	echo $html;

?>

