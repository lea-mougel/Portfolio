<?php 
include_once('myparam.inc.php');
function verif_pass($pwd){
	  
		$long=strlen($pwd);

		$pass_ok=true;

			if($long < 12) {
				$pass_ok=false;
			}
			$presence_minuscule = false;	
			$presence_majuscule=false;
			$presence_car_speciaux=false;
			for ($i =0; $i< $long; $i++)
				{
					$v = $pwd[$i];
					if ($v >='a' && $v <='z'){
						$presence_minuscule = true;
					}
					else {
						if ($v>='A' && $v<= 'Z') {
							$presence_majuscule=true;
						}
						else {
							if ($v=='!' || $v=='?' || $v=='_' || $v=='*' || $v==',') {
								$presence_car_speciaux=true;
							}
						}
					}	
				}
	
			if(!$presence_minuscule || !$presence_majuscule || !$presence_car_speciaux) {
				$pass_ok=false;
				}					
		
			return($pass_ok);
}
function verif_mail($mail) {
	  
		$long=strlen($mail);

		$mail_ok=true;

			if($long < 12) {
				$pass_mail=false;
			}
			$presence_arobase = false;	
			for ($i =0; $i< $long; $i++)
				{
					$v = $mail[$i];
					if ($v =='@'){
						$presence_arobase = true;
					}
				}
	
			if(!$presence_arobase) {
				$mail_ok=false;
				}					
		
			return($mail_ok);
}

function verif_user($pwd) {
		$nbrows = 0;
		if(!empty($pwd)){
		    $conn=pg_connect('host='.HOST.' dbname=coffrefort user='.USER.' password='.PASS);
		    
		    if(!$conn)  {
		    	 die("Erreur de connexion".pg_last_error());
		    }
		    $sql ="select pwd 
		    		  from pass 
		   		  where  pwd= '".$pwd."' ;";
	       $req = pg_query($conn, $sql);
	    
	       if(!$req){
		        die("erreur dans la requête".pg_last_error());
		     }
		
	        $nbrows= pg_num_rows($req); //nombre de lignes dans le résultat de la requête
	        pg_free_result($req);
	        pg_close($conn);	  
		}
	    return ($nbrows>0);
}
?>
