<?php 
include_once('myparam.inc.php');
include_once('verif.php');

$html="<html> <body>";
	if(isset($_POST['pwd']) && isset($_POST['mail']) && isset($_POST['tel'])) {
		
		if(verif_pass($_POST['pwd']) == false) {
			$html=$html."Veuillez entrer un mot de passe valide.";
		}
		else {
			if(verif_mail($_POST['mail']) ==false) {
				$html=$html." Veuillez entrer un email valide. ";
			}
			
			else {
				if(verif_user($_POST['pwd'])==true) {
					$html=$html." Cet utilisateur existe déjà. ";
				}
				else {
					if(!empty($_POST['pwd']) && !empty($_POST['mail']) && !empty($_POST['tel'])){
			    		$conn=pg_connect('host='.HOST.' dbname=coffrefort user='.USER.' password='.PASS);
			   		 if(!$conn)  {
			    			 die("Erreur de connexion".pg_last_error());
			   		 }
			   		 $sql ="INSERT into pass values (nextval('idpass'),'".$_POST['pwd']."','".$_POST['mail']."','".$_POST['tel']."');";
		       		 $req = pg_query($conn, $sql);
		    
		       		if(!$req){
			       		 die("erreur dans la requête".pg_last_error());
			    		}
			    		else {
							$html=$html." Compte créé ";	    			
			    		}
		        		pg_free_result($req);
		        		pg_close($conn);	  
				 	}
				 }
			}	
		}
	}
	
	$html.="	<fieldset ><form action='page_creation.php' method='post'>
	<label> Mot de passe maître :</label> <input type='text' name='pwd'>
	<label> Email :</label> <input type='mail' name='mail'>
	<label> Téléphone :</label> <input type='text' name='tel'>
	<br>
	<input type='submit' name='envoi' value='Créer'></form>
	<form action='accueil.php'>
		<input type='submit' name='envoi' value='Accueil'>
	</form>	</fieldset>
	</body> </html>";
	
	echo $html;

?>