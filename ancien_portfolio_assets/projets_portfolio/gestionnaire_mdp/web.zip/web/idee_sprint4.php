<?php /*
function supp($mdp2) {
		//fonction qui supprime le compte (mot de passe maître) de la base de donnée
		$conn2=pg_connect('host='.HOST.' dbname=coffrefort user='.USER.' password='.PASS);
		if(!$conn2)  {
			 die("Erreur de connexion".pg_last_error());
		}*/
	//sauvegarde dans une table d'historisation	    
		$date=date('Y-m-d');
		echo(getdate());
		echo($date);
	
		
	/*	
	//suppression	
		$sql2 ="DELETE FROM pass
		   	  where  pwd= '".$mdp2."' ;";
		   	
	    $req2 = pg_query($conn2, $sql2);
	   
	    if(!$req2){
	        die("erreur dans la requête".pg_last_error());
	     }
	    else{
			echo " Compte supprimé ";
			$_SESSION['connexion']=false;		    
	    }

		pg_free_result($req2);
		pg_close($conn2);	
	}*/
?>